/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Gaddis_Ch2.5_Average_of_values.cpp
 * Author: Ahmad.Okde
 *
 * Created on June 25, 2020, 10:25 PM
 */

//System Libraries Here
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number Seed Here
    srand(time(NULL));
    //Declare all Variables Here
    int a, b, c, d, e;
    int sum, average;
    //Input or initialize values Here
    a=rand()%100;
    b=rand()%100;
    c=rand()%100;
    d=rand()%100;
    e=rand()%100;

    //Process/Calculations Here
    sum = a+b+c+d+e;
    average = sum/5;
    //Output Located Here
    cout << "The average is: " << average << endl;
    //Exit
    return 0;
}

