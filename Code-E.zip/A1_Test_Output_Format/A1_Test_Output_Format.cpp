/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   A1_Test_Output_Format
 * Author: Ahmad.Okde
 *
 * Created on June 25, 2020, 10:19 PM
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip>
using namespace std;

//Execution Begins Here
int main(int argc, char** argv) {
    
   	int intNum;
   	float floatNum;
   	//input
   	cout << "Enter integer and then float: ";
   	cin >> intNum;
   	cin >> floatNum;
   	
   	//output
   	cout << intNum << endl;
   	cout << floatNum << endl;
   	cout << setw(16) << left << "Hello World" << endl;
   	cout << setw(6) << endl;
    
    //Exit stage left
    return 0;
}

