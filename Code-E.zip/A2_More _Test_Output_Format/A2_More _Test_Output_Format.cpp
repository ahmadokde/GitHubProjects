/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   A2_More _Test_Output_Format.cpp
 * Author: Ahmad.Okde
 *
 * Created on June 25, 2020, 10:23 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;
//System Libraries - Post Here
int main(int argc, char** argv) {
    //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    int n = 4;
    float num[4];
    //Initialize or input data here
    cout << "Enter 4 numbers: ";
    for (int i=0; i<n; i++)
    {
    	cin >> num[i];
	}
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    for (int i=0; i<n; i++)
    {
    	cout << setw(10) << num[i] << setw(10) << setprecision(1) << fixed << num[i] << setw(10) << setprecision(2) << fixed << num[i] << endl;
	}
    
    //Exit stage left
    return 0;
}

