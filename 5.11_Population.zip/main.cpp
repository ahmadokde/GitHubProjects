#include <iostream>
using namespace std;

double getValid(int max);


int main()
{
	double starting;
	double increase_percentage;
	double number_of_days;
	
	cout << "Enter starting number of organism: ";
	starting = getValid(2);
	
	cout << "Enter average daily population increase(percentage): ";
	increase_percentage = getValid(0);
	
	cout << "Enter number of days: ";
	number_of_days = getValid(1);
	
	int day = 1;
   while(day <= number_of_days)
   {
   		starting = starting * (increase_percentage / 100) + starting;
   		cout << "Day " << day << ": " << starting << endl;
   		day = day + 1;
   }
            
       
	return 0;
}

//function to get double value more than max
double getValid(int max)
{
	double num;
	cin >> num;
	while (num < max)
	{
		cout << "ERROR: Value must be atleast " << max << ". Try again: ";
		cin >> num;
	}
	return num;
}